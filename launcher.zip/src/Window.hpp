#ifndef WINDOW_H
#define WINDOW_H

#include <SDL3/SDL.h>
#include <nlohmann/json.hpp>
#include <vector>

#include "Structs.h"

class Application {
    public:
        Application();
        ~Application();
        void handleEvents();
        //void update();
        void draw();

        bool getIsRunning() { return isRunning; }
    private:
        SDL_Window* wnd;
        SDL_Renderer* ren;
        bool isRunning;
        std::vector<Xenia::Instance> instances;
};

#endif